# Mini CMS — claudiu-ghise.de
## Instrucțiuni de instalare pas cu pas

---

## 1. Copiază fișierele pe server

```bash
# Copiază folderul cms în rădăcina site-ului
cp -r ./cms /var/www/claudiu-ghise.de/cms
```

---

## 2. Instalează dependențele Node.js

```bash
cd /var/www/claudiu-ghise.de/cms
npm install
```

---

## 3. Testează că funcționează (opțional)

```bash
# Pornește manual ca test
ADMIN_USER=claudiu ADMIN_PASS=parola_ta SITE_ROOT=/var/www/claudiu-ghise.de node server.js

# Dacă vezi: "CMS API pornit pe http://127.0.0.1:3001" — funcționează!
# Oprește cu Ctrl+C
```

---

## 4. Configurează NGINX

Editează config-ul NGINX:
```bash
sudo nano /etc/nginx/sites-available/default
# sau
sudo nano /etc/nginx/sites-available/claudiu-ghise.de
```

Adaugă conținutul din `nginx-snippet.conf` în blocul `server {}`.

Testează și reîncarcă:
```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 5. Instalează ca serviciu systemd (pornire automată)

```bash
# Editează parola în fișier ÎNAINTE!
nano /var/www/claudiu-ghise.de/cms/claudiu-cms.service

# Copiază și activează serviciul
sudo cp /var/www/claudiu-ghise.de/cms/claudiu-cms.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable claudiu-cms
sudo systemctl start claudiu-cms

# Verifică statusul
sudo systemctl status claudiu-cms
```

---

## 6. Verifică permisiunile

Node.js trebuie să poată scrie în folderul site-ului:
```bash
sudo chown -R www-data:www-data /var/www/claudiu-ghise.de
sudo chmod -R 755 /var/www/claudiu-ghise.de
```

---

## 7. Accesează admin panel

Deschide în browser:
```
https://claudiu-ghise.de/admin
```

Loghează-te cu:
- **Username:** claudiu (sau ce ai setat în .service)
- **Parola:** ce ai setat în Environment=ADMIN_PASS

---

## Cum funcționează

| Secțiune | Ce face |
|----------|---------|
| **Proiecte** | Adaugă/editează/șterge proiecte. Salvarea regenerează automat `HTML/projects.html` |
| **Home / Bio** | Editează textul bio și cardurile. Salvarea regenerează `index.html` |
| **Imagini** | Vezi toate imaginile din `/Image/`, uploadează imagini noi |

---

## Schimbă parola

Editează `/etc/systemd/system/claudiu-cms.service`:
```
Environment=ADMIN_PASS=noua_parola_sigura
```
Apoi:
```bash
sudo systemctl daemon-reload
sudo systemctl restart claudiu-cms
```

---

## Probleme frecvente

**CMS-ul nu pornește:**
```bash
sudo journalctl -u claudiu-cms -n 50
```

**NGINX 502 Bad Gateway:**
- Verifică că Node.js rulează: `sudo systemctl status claudiu-cms`
- Verifică portul: `ss -tlnp | grep 3001`

**Permisiuni denied la scriere fișiere:**
```bash
sudo chown -R www-data:www-data /var/www/claudiu-ghise.de
```
